#include <iostream>
using namespace std;

struct struct1{
   char c;
   char d;
};

struct struct2{
   char c, d;
   double e;
};

struct struct3{
   char c,d,e;
   double f;
};

struct struct4{
   char c,d,e,f;
   double g;
};

struct struct5{

};

struct struct6{
   char c;
   int one; 
   char d;
};

struct struct7{
   char c;
   char d;
   int one; 
   
};
int main(){

   cout<<"Sizeof(s1): "<<sizeof(struct1)<<endl;
   cout<<"Sizeof(s2): "<<sizeof(struct2)<<endl;
   cout<<"Sizeof(s3): "<<sizeof(struct3)<<endl;
   cout<<"Sizeof(s4): "<<sizeof(struct4)<<endl;
   cout<<"Sizeof(s5): "<<sizeof(struct5)<<endl;
   cout<<"Sizeof(s6): "<<sizeof(struct6)<<endl;
   cout<<"Sizeof(s7): "<<sizeof(struct7)<<endl;

   return 0;
}