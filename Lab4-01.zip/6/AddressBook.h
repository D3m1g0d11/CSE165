#ifndef ADDRESS_H_
#define ADDRESS_H_

#include<iostream>
#include<string>

#include "Entry.h"

using namespace std;

typedef struct
{
    int size = 0;
    Entry *book[100];

    void add(Entry *a)
    {
        book[size] = a;
        size++;
    }
    void print()
    {
        for (int i = 0; i < size; i++)
        {
            cout << "First Name : " << book[i]->firstName << endl;
            cout << "Last Name : " << book[i]->lastName << endl;
            cout << "Email : " << book[i]->email << endl;
        }
    }
    void free()
    {
        for (int i = 0; i < size; i++)
        {
            delete book[i];
        }
        size = 0;
    }

} AddressBook;
#endif