
};

//2 chars followed by 1 int
struct s7{
   char c1,c2;
   int i;
};
