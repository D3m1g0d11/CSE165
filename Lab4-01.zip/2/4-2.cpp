#include <iostream>
#include <fstream>
#include <string>
#include "Stack.h"

using namespace std;

int main(){
    
    ifstream fin;
    struct Stack a;
    double n;
    fin.open("input.txt");
    a.initialize();
    while(fin >> n)
    {
        double *d = new double(n);
        a.push(d);
    }
    fin.close();

    while(a.head){
        cout<< *((double *)(a.pop())) << endl;
    }
    a.cleanup();
    return 0;
}