#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main(void)
{
	int count = 0;

	string line;

	ifstream fin;
	ifstream fin2;
	ofstream fout;

	string wordIn = "word_in.txt";

	fin.open(wordIn,ios::in);
	fout.open("words_out.txt");

	while(!fin.eof())
	{
		getline(fin,line);
		count++;
	}
	string* data = new string[count];
	fin2.open(wordIn,ios::in);
	for(int i = 0; i < count ; i++)
	{

		getline(fin2,data[i]);
		fout<<data[i]<<endl;
	}

	fin.close();
	fin2.close();
	fout.close();

	return 0;
}
