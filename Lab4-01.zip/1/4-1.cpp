#include <iostream>
#include <fstream>
#include <string>
#include "Stash.h"

using namespace std;

int main(){
    
    ifstream fin;
    struct Stash s;
    double n;
    fin.open("input.txt");
    s.initialize(10);
    while(!fin.eof())
    {
        fin >> n;
        s.add(&n);
    }
    fin.close();

    for(int i = 0; i < s.count(); i++){
        cout << *(double*) s.fetch(i) << "\n";
    }
    return 0;
}