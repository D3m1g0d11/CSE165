#ifndef Entry_h
#define Entry_h

#include <iostream>

using namespace std;

struct Entry {      
public:
    string firstName;
    string lastName;
    string email;

    void setName(string first){
        this -> firstName = first;
    }
    
    void setLastname(string last){
        this -> lastName = last;
    }

    void setEmail(string theirEmail){
        this -> email = theirEmail;
    }

    std::string getFirstName(){
        return (this -> firstName) ;
    }

    string getLastName(){
        return (this -> lastName);
    }

    string getEmail(){
        return (this -> email);
    }

    void print(){
        cout << "First Name: " << (this -> getFirstName()) << endl;
        cout << "Last Name: " << (this -> getLastName()) << endl;
        cout << "Email: " << (this -> getEmail()) << endl;
    }
};
#endif
