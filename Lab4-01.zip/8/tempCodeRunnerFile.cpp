
        
        cin >> a;
        cin >> b;
        s.setLetter(a);
        s.setTimes(b);
        s.print();
        if(s.getTimes() == 99 && s.getLetter() == '&'){
            break;
        }
    }

    cout <<endl << sizeof(s);
    return 0;
}