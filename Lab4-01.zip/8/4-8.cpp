#include <iostream>
#include <fstream>
#include <string>
#include "Stash.h"

using namespace std;

int main(){
    struct Stash s;
    string n;
    char space;
    int times;
    int incre;
    cin >> incre;
    s.inc(incre);
    char a;
    int b;

    while(1)
    {
        
        cin >> a;
        cin >> b;
        s.setLetter(a);
        s.setTimes(b);
        if(s.getTimes() == 99 && s.getLetter() == '&'){
            break;
        }else{
            s.print();
        }
    }

    cout << endl << sizeof(s);
    return 0;
}