#include <iostream>
#include <fstream>
#include "LinkedList.h"

using namespace std;

int main(){
    
    ifstream fin("input.txt");
    LinkedList a;
    a.initialize();
    
    float input;
        while(fin >> input){
                double* d = new double(input);
                a.add(d);
        }
        
        for(int i = 0; i < a.size; i++){
                double* f = (double*)(a.get(a.size - i -1));
                cout << *f << endl;
        }
        
        a.cleanup();
        return 0;
}