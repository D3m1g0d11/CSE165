#ifndef LinkedList_h
#define LinkedList_h

#include <iostream>

using namespace std;

struct LinkedList {      
public:
    struct Link { 
		void* data;
		Link* next;
		
		void initialize(void* dat, Link* nxt) {
			data = dat;
			next = nxt;
		}
        
	}* head;
    
    Link *end;
    int size;

    void initialize() {
            head = NULL;
            end = NULL;
            size = 0;
    } 
    void insertAtBack(void* val){   
        Link* link = new Link;
        link -> data = val;
        link -> next = NULL;
        if(head == NULL){
            head = link;
        }
        else{
            end -> next = link;
        }
        end = link;
        size++;   
    }

    void* get(int index) {
        if(index < 0 || index>=size){
                return NULL;
        }
        Link* curr = head;
        for(int i = 0; i < index; i++){
                curr = curr->next;
        }
        return curr -> data;
    }
void add(void* dat) {
        //creating a new node, setting dat as data and NULL as next
        Link *lnk = new Link();
        lnk->data = dat;
        lnk->next = NULL;
        //if head is NULL, setting lnk as head node
        if(head == NULL){
                head=lnk;
        }else{
                //else adding lnk as next of end
                end->next = lnk;
        }
        //setting lnk as new end node, updating size
        end=lnk;
        size++;
}


    void cleanup() {
        while(head!=NULL){
                //taking a reference to next of head
                Link* next=head->next;
                //deleting head
                delete head;
                //setting next as new head
                head=next;
        }
        //resetting end and size
        end=NULL;
        size=0;
    }
};
#endif
