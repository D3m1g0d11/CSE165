#include <iostream>
void triple (int& x)
{
        x = x * 3;
}