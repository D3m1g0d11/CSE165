
           while (tmp != NULL) {
               //tmp = static_cast<Rect *> (storage.fetch(i));